from random import *

sales = {
    'John':  {'N': 3056, 'S': 8463, 'E': 8441, 'W': 2694},
    'Tom':   {'N': 4832, 'S': 6786, 'E': 4737, 'W': 3612},
    'Anne':  {'N': 5239, 'S': 4802, 'E': 5820, 'W': 1859},
    'Fiona': {'N': 3904, 'S': 3645, 'E': 8821, 'W': 2451}
}

for i in sales:
    print(i, sep="")
    for a in sales[i]:
        print(a, " : ", sales[i][a], sep="")

while True:
    n = input("Имя: ")
    for i in sales:
        if n == i:
            cnt = input("Регион: ")
            for a in sales[i]:
                if cnt == a:
                    print(sales[i][a])
                    new = int(input("Новое значение: "))
                    sales[i][a] = new
            print(sales[i])
            break
    else:
        print("Нет такого имени в списке")
    break
