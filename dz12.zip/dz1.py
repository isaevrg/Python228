from random import *

# sales = {
#     'John':  {'N': 3056, 'S': 8463, 'E': 8441, 'W': 2694},
#     'Tom':   {'N': 4832, 'S': 6786, 'E': 4737, 'W': 3612},
#     'Anne':  {'N': 5239, 'S': 4802, 'E': 5820, 'W': 1859},
#     'Fiona': {'N': 3904, 'S': 3645, 'E': 8821, 'W': 2451}
# }
#
# for i in sales:
#     print(i, sep="")
#     for a in sales[i]:
#         print(a, " : ", sales[i][a], sep="")
#
# while True:
#     n = input("Имя: ")
#     for i in sales:
#         if n == i:
#             cnt = input("Регион: ")
#             for a in sales[i]:
#                 if cnt == a:
#                     print(sales[i][a])
#                     new = int(input("Новое значение: "))
#                     sales[i][a] = new
#             print(sales[i])
#             break
#     else:
#         print("Нет такого имени в списке")
#     break


# 1 задание
# a = {1: 10, 2: 20}
# b = {3: 30, 4: 40}
# c = {5: 50, 6: 60}
# d = a | b | c
# print(d)
# print({**a, **b, **c})

# 2 задание
# emp = {
#     'emp1':  {'name': 'Jhon', 'salary': 7500},
#     'emp2':  {'name': 'Emma', 'salary': 8000},
#     'emp3':  {'name': 'Brad', 'salary': 6500},
# }
#
# for i in emp:
#     print(i, sep="")
#     for a in emp[i]:
#         if i == 'emp3':
#             emp[i]['salary'] = 8500
#             print(a, " : ", emp[i][a], sep="")


# 3 задание

n = int(input("Введите количество студентов: "))
a = {}
sum1 = 0
for i in range(n):
    name = input(str(i + 1) + "-й студент: ")
    p = int(input("Бал: "))
    a[name] = p
    sum1 += p

sred = sum1 / n
print("Средний балл: ", round(sred, 1))
print("Студент с баллом выше среднего: ")
for i in a:
    if a[i] > sred:
        print(i)

