# 1 задание
from random import *

# a = 'ab', 'abcd', 'cde', 'abc', 'def'
# print(a)
# s = input("s = ")
#
# if s in a:
#     print("Yes")
# else:
#     print("No")

# 2 задание
# a = tuple(input("Введите по порядку, без пробелов, элементы кортежа: "))
# print(a)
# print("количество 0 =", (a.count("0")))
# print("количество 1 =", (a.count("1")))
# print("количество 2 =", (a.count("2")))
# print("количество 3 =", (a.count("3")))
# print("количество 4 =", (a.count("4")))
# print("количество 5 =", (a.count("5")))
# print("количество 6 =", (a.count("6")))
# print("количество 7 =", (a.count("7")))
# print("количество 8 =", (a.count("8")))
# print("количество 9 =", (a.count("9")))

# 3 задание

numb = [int(input('-> '))for i in range(int(input('Введите количество элементов: ')))]


def num():
    s = 0
    for i in numb:
        if i != 0 and i % 13 == 0:
            if i > s:
                s = i
                return s
            else:
                return "no such numbers"


r = num()
print(r)



